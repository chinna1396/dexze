const abouthome = () => {
  return (
    <div className="abouthome">
      <h1> We believe in the power of stories.</h1>
      <p>
        Dexze is the agency with the strategies, ideas, creative, and digital
        technology to connect with people today, across websites, social media,
        branding, marketing, and more. We do everything you’d expect from a
        creative agency; we’ve just erased the lines between the strategy, media
        and creative departments. Everyone on our team has fully functioning
        left and right brains, so we all wear multiple hats to get the job done.
      </p>
      <div className="first-des">
        <div className="des-text">
          <h2></h2>
        </div>{" "}
      </div>
    </div>
  );
};
export default abouthome;
